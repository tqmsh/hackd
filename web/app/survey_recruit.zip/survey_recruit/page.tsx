import SurveyForm from "./SurveyRecruitingPage/SurveyRecruit";

export default function HomePage() {
  return <SurveyForm/>;
}